<?php
include("connection2.php");
$sql="select * from detail";
$result=mysqli_query($conn,$sql);


while($row=mysqli_fetch_assoc($result))
{
  
echo $row['ROLL'].";". $row['PASS'].";";
}
?>