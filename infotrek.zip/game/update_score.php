<?php
	
	include('connection2.php');
	$username =$_POST["username"];
	$score =$_POST["score"];
    $date = date("Y-m-d H:i:s");
	echo $date;
$sql="select score from game where uname='".$username."'";

//echo $sql;
 $result = mysqli_query($conn ,$sql);
 echo $score;
 $score_get=mysqli_fetch_assoc($result);
 echo $score_get['score'];
  if($score_get['score']<$score)
 { 
  $insert="update game set score = $score,time='".$date."' where uname = '".$username."'";
  $result = mysqli_query($conn ,$insert);
 
	if(!$result) echo "there was an error";
	else echo "Everything ok.";
}

?>