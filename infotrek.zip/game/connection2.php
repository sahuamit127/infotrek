<?php
$conn=mysqli_connect("localhost","amitsahu","D[Hvx{@4w)RJ","infotrek");

?>