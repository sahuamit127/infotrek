<?php
session_start();
include('connection2.php');
function filterName($field)
 {
    $field = filter_var(trim($field), FILTER_SANITIZE_STRING);
    if(filter_var($field, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+/")))){
        return $field;
    }else{
        return FALSE;
    }
}
function filterpass($field)
 {
    $field = filter_var(trim($field), FILTER_SANITIZE_STRING);
    if(filter_var($field, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[0-9a-zA-Z\s]+/")))){
        return $field;
    }else{
        return FALSE;
    }
}

function filterrollno($field)
{
    $field = filter_var(trim($field), FILTER_SANITIZE_STRING);
    if(filter_var($field, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[0-9]{9}+$/")))){
        return $field;
    }else{
        return FALSE;
    }
}
function filtercontact($field)
{
    $field = filter_var(trim($field), FILTER_SANITIZE_STRING);
    if(filter_var($field, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[0-9]{10}+$/")))){
        return $field;
    }else{
        return FALSE;
    }
}   
function filterEmail($field)
{
    $field = filter_var(trim($field), FILTER_SANITIZE_EMAIL);
     if(filter_var($field, FILTER_VALIDATE_EMAIL)){
        return $field;
    }else{
        return FALSE;
    }
}  
$fname1 =$email1=$lname1=$deg1=$rno1=$cno1=$psw1="";
if($_SERVER["REQUEST_METHOD"] == "POST")
{
    if(empty($_POST["fname"]))
  {      $fnameErr= $_SESSION["msg7"] = "Please enter your name.";
        echo "1";
    }else{
        $fname1 = filterName($_POST["fname"]);
        if($fname1 == FALSE){
            $fnameErr=$_SESSION["msg7"] = "Firstname must have alphabet characters only.";
           echo '<script type="text/javascript">'; 
        echo 'alert("Firstname must have alphabet characters only.")'; 
        echo 'window.location= "index.php"';
        echo '</script>';
        }
		else{
			$fnameErr="";
		}

  }
    if(empty($_POST["lname"]))
  {    $lnameErr= $_SESSION["msg8"] = "Please enter your name.";
        echo "177";
    }else{
        $lname1 = filterName($_POST["lname"]);
        if($lname1 == FALSE){
            $lnameErr=$_SESSION["msg8"] = "lastname must have alphabet characters only.";
            echo '<script type="text/javascript">'; 
        echo 'alert("Lastname must have alphabet characters only.");'; 
        echo 'window.location= "index.php"';
        echo '</script>';
        }
		else{
			$lnameErr="";
		}
  }
    if(empty($_POST["email"]))
    {
           $emailErr=$_SESSION["msg9"] = "Please enter email.";
        echo "4";
    }else{
        $email1 = filterEmail($_POST["email"]);
        if($email1 == FALSE){
      $emailErr= $_SESSION["msg9"] = "Please enter a valid email.";
      echo '<script type="text/javascript">'; 
        echo 'alert("Please enter a valid email.");'; 
        echo 'window.location= "index.php"';
        echo '</script>';
        }
		else{
			$emailErr="";
		}
		
    }
     
  if(empty($_POST["rno"]))
  {     $rnoErr=$_SESSION["msg11"] = "Please enter your Roll No.";
       echo "6";
    }else{
        $rno1 = filterrollno($_POST["rno"]);
        if($rno1 == FALSE){
             $rnoErr=$_SESSION["msg11"] = "Firstname must have alphabet characters only.";
            echo '<script type="text/javascript">'; 
        echo 'alert("Roll Number must contain 9 digit.");'; 
        echo 'window.location= "index.php"';
        echo '</script>';
        }
		else{
			$rnoErr="";
		}
  }
  if(empty($_POST["cno"]))
  {   $cnoErr=$_SESSION["msg12"] = "Please enter your name.";
      echo "8";
    }else{
        $cno1 = filtercontact($_POST["cno"]);
        if($cno1 == FALSE){
             $cnoErr=$_SESSION["msg12"] = "Firstname must have alphabet characters only.";
            echo '<script type="text/javascript">'; 
        echo 'alert("Contact number is invalid.");'; 
        echo 'window.location= "index.php"';
        echo '</script>';
        }
		else{
			$cnoErr="";
		}
      }
        if(empty($_POST["psw"]))
  {        $pswErr=$_SESSION["msg13"] = "Please enter your name.";
        
    }else{
        $psw1 = filterpass($_POST["psw"]);
        if($psw1 == FALSE){
             $pswErr=$_SESSION["msg13"] = "Firstname must have alphabet characters only.";
           echo '<script type="text/javascript">'; 
        echo 'alert("Please enter valid detail.");'; 
        echo 'window.location= "index.php"';
        echo '</script>';
  }
  else{
			$pswErr="";
		}
 }
 if( $fnameErr=="" &&  $lnameErr=="" &&  $emailErr==""  && $rnoErr=="" && $cnoErr=="" && $pswErr=="")
 {
$conn=mysqli_connect("localhost","amitsahu","D[Hvx{@4w)RJ");

if($conn)
{
	$db=mysqli_select_db($conn,"infotrek");
	if($db)
	{
                $sql1="SELECT id FROM sign1 WHERE rno='".$_POST["rno"]."'";
	        $res1=mysqli_query($conn,$sql1);
	         $count=mysqli_num_rows($res1);
           if($count==1)
           {
           	$_SESSION["msg1"]="roll no. already exist.";
           	  echo '<script type="text/javascript">'; 
        echo 'alert("roll no. already exist.");'; 
        echo 'window.location= "index.php"';
        echo '</script>';
           }
         else{
           
    
   
        $email=$_POST["email"];  
		$fname=$_POST["fname"];
		$lname=$_POST["lname"];
		$pass=$_POST["psw"];
     $pass1=sha1($pass);
		$rno=$_POST["rno"];
		$cpass=$_POST["cpsw"];
		 $cpass=sha1($cpass);

		$cno=$_POST["cno"];
		$dep=$_POST["department"];
	
          
		if($pass1!=$cpass)
		{
			$_SESSION["message"]="Password does not match.";
			echo '<script type="text/javascript">'; 
        echo 'alert("Password does not match.");'; 
        echo 'window.location= "index.php"';
        echo '</script>';
		}
		else{
		$sql="INSERT INTO  sign1 (fname,lname,email,rno,psw,cpsw,cno,department) VALUES ('".$fname."','".$lname."','".$email."','".$rno."','".$pass1."','".$cpass."','".$cno."','".$dep."')";
	     $sql1="INSERT INTO  detail (NAME,ROLL,PASS) VALUES (concat('".$fname."',' ','".$lname."'),'".$rno."','".$pass."')"; 
    $res1=mysqli_query($conn,$sql1);
    $sql3="INSERT INTO  game (uname) VALUES ('".$rno."')"; 
    $res3=mysqli_query($conn,$sql3);
     $sql2="INSERT INTO  user_score (name,user_name,password) VALUES (concat('".$fname."',' ','".$lname."'),'".$rno."','".$pass."')"; 
    $res2=mysqli_query($conn,$sql2);
		$res=mysqli_query($conn,$sql);
		if($res)
		{
		$_SESSION["message1"]="Registered Successfully. ";
			  echo '<script type="text/javascript">'; 
        echo 'alert("Registered Successfully.");'; 
        echo 'window.location= "index.php"';
        echo '</script>';


		}
		else
		{
		$_SESSION["message11"]="<h3>SERVER INTERUPTED</h3>".mysql_error();
				 echo '<script type="text/javascript">'; 
        echo 'alert("SERVER INTERUPTED Please Try Again");'; 
        echo 'window.location= "index.php"';
        echo '</script>';
		}}
	}
	}
	else  
	{
	echo "DATA SIDE PROBLEM".mysql_error();
	}
}
else
{
echo "SERVER SIDE PROBLEM".mysql_error();
  }}
  else{
	  echo '<script type="text/javascript">'; 
        echo 'alert("details incorrect.");'; 
        echo 'window.location= "index.php"';
        echo '</script>';
	 
  }
  }
?>
