<!DOCTYPE html>
<html lang="en" >

<head>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-134427101-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-134427101-1');
</script>
  <title>INFOTREK'19</title>
 <link rel="icon" href="img/acm.png" type="image/gif" sizes="16x16">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Iceland" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/nevi.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
	<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Iceland" />
	 <link rel="stylesheet" href="css/event1.css">
	 <link rel="stylesheet" href="css/button.css">
	 <link rel="stylesheet" href="css/event_popup.css">
  <link rel="stylesheet" href="css/animate.min.css">
  <style>
.grid-container {
  display: grid;
  grid-template-columns: 200px 200px 200px 200px;
  grid-template-rows: 200px 200px;
  grid-gap: 60px;
  background: none;
  padding: 10px;
}
  .border{
	  text-shadow: 1px 1px 2px black, 0 0 25px blue, 0 0 5px darkblue;
	    font-weight: 950;
		font-family:iceland;
}
  .cc{
   position:absolute;top:162px;left:440px;
  }
.grid-container > div {
  background-color: #fff;
  text-align: center;
  padding: 20px 0;
  font-size: 30px;
}
@media only screen and (max-width:500px) {
  /* For tablets: */
  .grid-container {
    width: 100%;
    padding: 0;
  }

 
}
</style>
<style>

.mydiv {
 border-radius: 50%;
  animation: myanimation 10s infinite;
}
.sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 5;
  top: 0;
  left: 0;
  background-color:#111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #fff;
  display: block;
  transition: 0.3s;

}
.border{
	  text-shadow: 1px 1px 2px black, 0 0 25px blue, 0 0 5px darkblue;
	    font-weight: 950;
		font-family:iceland;
}
 .cc{
   position:absolute;top:300%;left:29%;
  }
.sidenav a:hover {
  color: white;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}


@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>
</head>

<body id="acm">
        <div class="main">
	         <br><br>&nbsp;&nbsp;&nbsp;&nbsp;
             <span style="font-size:40px;color:white;cursor:pointer" onclick="openNav()">&#9776; </span>
			
           
			   <img src="img/events.png" class="event_name">
         <div class="row1">
  
  <div class="column1">
    <a href="javascript:void(0)" onclick="opendiv('ev1','de1')" class="k"> <img src="img/affiche.png" alt="Snow" class="f p1 animated slideInLeft" style="animation-delay:1s;"></a>
  </div>
  <div class="column1">
    <a href="javascript:void(0)" onclick="opendiv('ev2','de2')" class="k"><img src="img/codestorm.png" alt="Snow" class="f p2 animated slideInLeft " style="animation-delay:0.5s;"></a>
  </div>
  <div class="column1">
   <a href="javascript:void(0)" onclick="opendiv('ev3','de3')" class="k"> <img src="img/mining-the-jewels.png"  alt="Snow" class="f animated slideInDown  p3  " style="animation-delay:0.2s;"></a>
  </div>
  <div class="column1" >
   <a href="javascript:void(0)" onclick="opendiv('ev4','de4')" class="k">  <img src="img/defenders.png" alt="Snow" class="f p2 animated slideInRight" style="animation-delay:0.5s;"></a>
  </div>
  <div class="column1">
   <a href="javascript:void(0)" onclick="opendiv('ev5','de5')" class="k">  <img src="img/debug.png" alt="Snow" class="f p1 animated slideInRight" style="animation-delay:1s;"></a>
  </div>
  
</div><br>
	   <div class="row1 ">
  <div class="column1 ">
    <a href="javascript:void(0)" onclick="opendiv('ev6','de6')" class="k"> <img src="img/weavo.png" alt="Snow" class="f p4  animated slideInLeft" style="animation-delay:1s;"></a>
  </div>
 <div class="column1" >
   <a href="javascript:void(0)" onclick="opendiv('ev7','de7')" class="k">  <img src="img/video.png" alt="Snow" class="f p6  animated slideInLeft" style="animation-delay:0.5s;"></a>
  </div>
  <div class="column1">
   <a href="javascript:void(0)" onclick="opendiv('ev8','de8')" class="k">  <img src="img/sharp.png" alt="Snow" class="f p5  animated slideInUp" style="animation-delay:0.2s;"></a>
  </div>
   <div class="column1" >
   <a href="javascript:void(0)" onclick="opendiv('ev9','de9')" class="k">  <img src="img/ULTIMATE.png" alt="Snow" class="f p6  animated slideInRight" style="animation-delay:0.5s;"></a>
  </div>
  <div class="column1">
   <a href="javascript:void(0)" onclick="opendiv('ev10','de10')" class="k">  <img src="img/quiz.png" alt="Snow" class="f p4  animated slideInRight" style="animation-delay:1s;"></a>
  </div>
</div>		
			
			
			
			
			
			
			
    </div>
	<div id="mySidenav" class="sidenav" style="position:absolute;z-index:3;">
         <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
         <img src="img/logo.png" style="height:79px;width:261px;" align="right">
         <a href="index.php" class="border ">HOME</a>
		 <a href="javascript:void(0)" onclick="opendv()" class="border">ABOUT</a>
		 <a href="event.php" class="border">EVENTS</a>
		 <a href="glimpse.php" class="border">GLIMPSE</a>
		 <a href="team.php" class="border">TEAM</a>
		 <a href="contact.php" class="border">CONTACT</a>
		  <a href="javascript:void(0)" onclick="opendiv('reg')" class="border">REGISTER</a>
    </div>

<?php include("footer.php"); ?>



 
	<!-- this is for about popup  -->
	<div class='overlay animated slideInDown' id="about" >
   <a href="javascript:void(0)" class="closediv" onclick="closedv()">&times;</a>
  <P class="blocktext">
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <h2 style="font-family:Iceland;text-align:center;">ABOUT</h2><hr>
  Infotrek is an Inter-Department technical meet that is conducted every year. The festival includes Seminars and Guest Lectures by the software professionals from various organizations who have gained expertise in their field.The Department of Computer Applications has the unique distinction of being the pioneer in establishing India's first ACM Student's Chapter . ACM's headquarter is located in New York. It is dedicated to spreading computer awareness among students.This chapter regularly conducts seminars, lecture series and quiz contests apart from conducting annual meets like ACUMEN and INFOTREK. This chapter also releases a monthly online news magazine called the "ACM Newsletter" which keeps us abreast of the latest developments in the IT industry. ACM sponsors candidates for various MCA meets where our students participate and emerge in flying colours. Infotrek 2019 will be held from 23th february - 24th february 2019.
		</p>
 
  </div>
  <!-- all are events detail popup-->
  <!-- event 1-->
   <div class='overlay animated slideInDown' id="ev1" >

		<a href="javascript:void(0)" class="closediv" onclick="closediv('ev1')">&times;</a>
			<div class="inner_div">
				<button class="tablink" onclick="openPage('ab1', this, '#777')" id="de1">About</button>
				<button class="tablink" onclick="openPage('rules1', this, '#777')" >Rules</button>



					<div id="ab1" class="tabcontent">
						<h1 style="text-align:center;color:#fa4107;"><br>AFFICHE GATEWAY</h1><br>
						<p>Imagination has a great deal to do with winning, so imagine and innovate something different. It is an online poster submission event and participants have to doodle something . </p>
					   <br><br>
					</p>
					<br>
					<p align="center"><a href="https://www.facebook.com/infotrek19/?modal=admin_todo_tour" class="button blue ">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Upload here &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></p><hr>
					</div>

					<div id="rules1" class="tabcontent">
							<h3></h3>
								<p>
								<h1 style="text-align:center;color:#fa4107;"><br>AFFICHE GATEWAY</h1><br>	
									♦ Each participant has to submit a poster by uploading it on facebook page of ACM INFOTREK19<br>
									♦ You have to prepare a poster on the topic INFOTREK.<br>
									♦ You can start uploading poster from 16 February, last date is 22nd February. <br>
								</p> 
					</div>

			</div>
	</div>
	<!-- event 2-->
	<div class='overlay animated slideInDown' id="ev2" >

		<a href="javascript:void(0)" class="closediv" onclick="closediv('ev2')">&times;</a>
			<div class="inner_div">
				<button class="tablink de1" onclick="openPage('ab2', this, '#777')" id="de2">About</button>
				<button class="tablink" onclick="openPage('rules2', this, '#777')" >Rules</button>



					<div id="ab2" class="tabcontent">
						<h1 style="text-align:center;color:#fa4107;"><br>CODESTORM</h1><br>
						<p>Winning isn’t everything ,but it beats everything that comes in second.
						It is an online coding event. </p><BR>
					</p><hr>
					
					</div>

					<div id="rules2" class="tabcontent">
							<h1 style="text-align:center;color:#fa4107;"><br>CODESTORM</h1><br>
								<p>
									♦ Each team can have two participants.<br>
♦ No contestant can be a member of more than one team.<br>
♦ No Registration is Required.<br>
♦ Teams involving in any malpractices will be disqualified.<br>

It will be an online test where you will be tested with basic programming skills in C/C++. 
								</p> 
					</div>

			</div>
	</div>
	<!-- event 3-->
	<div class='overlay animated slideInDown' id="ev3" >

		<a href="javascript:void(0)" class="closediv" onclick="closediv('ev3')">&times;</a>
			<div class="inner_div">
				<button class="tablink" onclick="openPage('ab3', this, '#777')" id="de3">About</button>
				<button class="tablink" onclick="openPage('rules3', this, '#777')" >Rules</button>



					<div id="ab3" class="tabcontent">
						<h1 style="text-align:center;color:#fa4107;"><br>Mining The Jewels</h1><br>
						<p>Just think outside of the box. It is an online treasure hunt game event where participants can win by submitting the correct logical
						answer for the given images. It consists of three levels-easy,moderate,tough. </p><br><br>
						<p align="center"><a href="hunt1/login.php" class="button blue ">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; enter Contest &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
						
						<a href="hunt1/leaderboard.php" class="button blue ">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; leader board &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></p><hr>
					
					
					</div>

					<div id="rules3" class="tabcontent">
						<h1 style="text-align:center;color:#fa4107;"><br>Mining The Jewels</h1><br>
								<p>
									♦ enter only one word in answer, In lower case without any space.<br>
♦ Use your nine digit roll number for login.<br>
♦ Save your hits ,you have only 4000 hits. You will warned once when you cross danger zone.<br>
♦ Two hints will be given.<br>
♦ A particular question’s marks will be decreased for wrong answer.<br>
♦ If someone submit answer before you then question’s marks will be decreased.<br>
♦ ♦ Suggestions :<br>
♦ Play in pc on full screen .<br>
♦ Don’t cheat other wise you will be disqualified .   

								</p> 
					</div>

			</div>
	</div>
	<!--event 4-->
	<div class='overlay animated slideInDown' id="ev4" >

		<a href="javascript:void(0)" class="closediv" onclick="closediv('ev4')">&times;</a>
			<div class="inner_div">
				<button class="tablink" onclick="openPage('ab4', this, '#777')" id="de4">About</button>
				<button class="tablink" onclick="openPage('rules4', this, '#777')" >Rules</button>



					<div id="ab4" class="tabcontent">
					<h1 style="text-align:center;color:#fa4107;"><br>DEFENDERS OF TIME</h1><br>
						
						<p>The only hurdle between you and victory will be the callibre
						of your conditional statements.This is an event that challenges
						your coding expertise to the extreme. 
						It is a coding event where a correct code which has no wrong submission matters for chance 
						to conquer the leaderboard. </p>
					</p><hr>
					
					</div>

					<div id="rules4" class="tabcontent">
						<h1 style="text-align:center;color:#fa4107;"><br>DEFENDERS OF TIME</h1><br>
								<p>
									♦ Each participant will have to individually register for this contest.<br>
									♦ Participants will be registered with their Hackerrank IDs.<br>
									♦ Only registered participants can take part in this online event.<br>
									♦ Participants involving in any malpractices will be disqualified.<br>
									♦ The event will be held on 23th February.<br>
									♦ You will be given a total time of one hour and for each wrong submission few minutes will be deducted from the total time. So, you have to defend your time.<br><br>
									Prelims:-
It will be a coding test where you will be tested with basic programming skills in C/C++.
Finals:-
Shortlisted teams will be having a computer-based test where you will face complex problems.
								
								</p> 
					</div>

			</div>
	</div>
	<!--event 5-->
	<div class='overlay animated slideInDown' id="ev5" >

		<a href="javascript:void(0)" class="closediv" onclick="closediv('ev5')">&times;</a>
			<div class="inner_div">
				<button class="tablink" onclick="openPage('ab5', this, '#777')" id="de5">About</button>
				<button class="tablink" onclick="openPage('rules5', this, '#777')" >Rules</button>



					<div id="ab5" class="tabcontent">
						<h1 style="text-align:center;color:#fa4107;"><br>DEBUG++ </h1><br>
						<p> If you fancy yourself to be one of them,then participate to
						begin your march towards ultimate glory. It is an offstage event
						of team of two, where some coding questions will be given and 
						participants have to find the bug and then replace that one with
						correct one.</p>
					</p><hr>
					
					</div>

					<div id="rules5" class="tabcontent">
							<h1 style="text-align:center;color:#fa4107;"><br>DEBUG++ </h1><br>
								<p>
									♦ Each team can have two participants.<br>
♦ No contestant can be a member of more than one team.<br>
♦ No Registration is Required.<br>
♦ Teams involving in any malpractices will be disqualified. 
<br>
♦ You have to Debug a given code so that it can work for all the test cases. 
<br> 
							* Violation of any rule mentioned above can lead to disqualification at any point of time.<br>
									** The organizers reserve the right to change/update the rules of the contest at any point of time and will do their best to inform the participants. However, it is ultimately the teams' responsibility to keep themselves updated.
								</p>  
					</div>

			</div>
	</div>
	<!--event 6-->
	<div class='overlay animated slideInDown' id="ev6" >

		<a href="javascript:void(0)" class="closediv" onclick="closediv('ev6')">&times;</a>
			<div class="inner_div">
				<button class="tablink" onclick="openPage('ab6', this, '#777')" id="de6">About</button>
				<button class="tablink" onclick="openPage('rules6', this, '#777')" >Rules</button>



					<div id="ab6" class="tabcontent">
					<h1 style="text-align:center;color:#fa4107;"><br>WEAVE-O-WEB </h1><br>
						
						<p>Get ready to tinker with cutting edges ideas and revolutionize our
						everyday lives.
						It is an offstage event. In this event participants have to show 
						their creativity and innovative ideas in the field of web desigining.  </p>
					</p><hr>
					
					</div>

					<div id="rules6" class="tabcontent">
							<h1 style="text-align:center;color:#fa4107;"><br>WEAVE-O-WEB </h1><br>
							<p>
♦ Each team can have two participants.<br>
♦ No contestant can be a member of more than one team.<br>
♦ No Registration is Required.<br>
♦ Teams involving in any malpractices will be disqualified.<br>
♦ Decision of the jury will be final and binding.<br>

* Violation of any rule mentioned above can lead to disqualification at any point of time.<br>
** The organizers reserve the right to change/update the rules of the contest at any point of time and will do their best to inform the participants. However, it is ultimately the teams' responsibility to keep themselves updated.

								</p> 
					</div>

			</div>
	</div>
	<!--event 7-->
	<div class='overlay animated slideInDown' id="ev7" >

		<a href="javascript:void(0)" class="closediv" onclick="closediv('ev7')">&times;</a>
			<div class="inner_div">
				<button class="tablink" onclick="openPage('ab7', this, '#777')" id="de7">About</button>
				<button class="tablink" onclick="openPage('rules7', this, '#777')" id="defaultOpen">Rules</button>



					<div id="ab7" class="tabcontent">
							<h1 style="text-align:center;color:#fa4107;"><br>VACIO-EDITAR </h1><br>
						<p> It is a  video-editing event, where  participants have to give their individual submissions. The topic for video-editing is ACM Infotrek19 TEASER                      .  Just try to Capture Greatness ,collaborate and create.</p>
					</p><br>
					<p align="center"><a href="https://www.facebook.com/infotrek19/?modal=admin_todo_tour" class="button blue ">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Upload here &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></p><hr>
					
					</div>

					<div id="rules7" class="tabcontent">
							<h1 style="text-align:center;color:#fa4107;"><br>VACIA-EDITAR </h1><br>
							<p>
									♦ Only individual participants are allowed.<br>
♦ You can start submitting the edited video by uploading it on the facebook page of ACM Infotrek19 from 16th February.<br>
♦ Last date for submission is 22nd February.<br>
♦ Participant involving in any malpractices will be disqualified.<br>
♦ Decision of the jury will be final and binding.<br>
								</p>  
					</div>

			</div>
	</div>
	<!--event 8-->
	<div class='overlay animated slideInDown' id="ev8" >

		<a href="javascript:void(0)" class="closediv" onclick="closediv('ev8')">&times;</a>
			<div class="inner_div">
				<button class="tablink" onclick="openPage('ab8', this, '#777')" id="de8">About</button>
				<button class="tablink" onclick="openPage('rules8', this, '#777')" id="defaultOpen">Rules</button>



					<div id="ab8" class="tabcontent">
						<h1 style="text-align:center;color:#fa4107;"><br> SHARPHUNT </h1><br>
						<p>Knowing isn’t enough,we must apply. Willing is not
						enough,we must do. Sharphunt is an offstage event of team
						of two where we will provide a platform for instant learn 
						and instant code. It will check your learning capacity.
						A perfect opportunity for you to satiate your curiosity. </p>
					</p><hr>
					
					</div>

					<div id="rules8" class="tabcontent">
						<h1 style="text-align:center;color:#fa4107;"><br> SHARPHUNT </h1><br>
							<p>
							    	♦ Each team will be of two members.<br>
									♦ Each team will have to individually register for this contest.<br>
									♦ Participants will be registered with their Hackerrank IDs.<br>
									♦ Only registered participants can take part in this online event.<br>
									♦Participants involving in any malpractices will be disqualified.<br>
									♦ The event will be held on 23th February.<br>
									♦ You will be given a total time of two hour in which one hour will be for learning a new programming language and another hour to code some basic questions only in that language.<br><br>
								</p> 
					</div>

			</div>
	</div>
		<!--event 9-->
	<div class='overlay animated slideInDown' id="ev9" >

		<a href="javascript:void(0)" class="closediv" onclick="closediv('ev9')">&times;</a>
			<div class="inner_div">
				<button class="tablink" onclick="openPage('ab9', this, '#777')" id="de9">About</button>
				<button class="tablink" onclick="openPage('rules9', this, '#777')" id="defaultOpen">Rules</button>



					<div id="ab9" class="tabcontent">
						<h1 style="text-align:center;color:#fa4107;"><br>ULTIMATE WARRIOR</h1><br>
						<p>Ultimate Warrior is an action adventure game in which the player has to collect as many possible NIDS(treasure keys) and to explore the whole area in order to complete the game. There are different types of NIDS based on their size they provide the score, the player has to fight enemies and increase its score in order to win.  </p>
					</p><br>
						<p align="center"><a href="#" class="button blue ">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; enter Contest &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
						
						<a href="game/leaderboard.php" class="button blue ">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; leader board &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></p><hr>
					
					</div>

					<div id="rules9" class="tabcontent">
							<h1 style="text-align:center;color:#fa4107;"><br>ULTIMATE WARRIOR</h1><br>
								<p>
									♦ Movement keys:
     Left: A, Right: D, Crouch: S, Jump: Space, Melee Attack: k,
     Ranged Attack: O.<br>
	♦ Winner of the game is chosen on the basis of their scores in game.
								</p>  
					</div>

			</div>
	</div>
		<!--event 10-->
	<div class='overlay animated slideInDown' id="ev10" >

		<a href="javascript:void(0)" class="closediv" onclick="closediv('ev10')">&times;</a>
			<div class="inner_div">
				<button class="tablink" onclick="openPage('ab10', this, '#777')" id="de10">About</button>
				<button class="tablink" onclick="openPage('rules10', this, '#777')" id="defaultOpen">Rules</button>



					<div id="ab10" class="tabcontent">
						<h1 style="text-align:center;color:#fa4107;"><br>QUIZTICA</h1><br>
						<p>It is both offstage and onstage  quiz event consisting 
						of prelims as offstage and mains as onstage. </p>
					</p><hr>
					
					</div>

					<div id="rules10" class="tabcontent">
							
								<p>
									
♦ Each team can have two participants.<br>
♦ No contestant can be a member of more than one team.<br>
♦ No Registration is Required.<br>
♦ The participants are not be allowed to use mobile phones or other electronic instruments.<br>
♦ Teams involving in any malpractices will be disqualified.<br>
Prelims:-
It will be an online test judging your awareness.<br>
Finals:-
On-stage final round.<br>
It will be an online test judging your awareness.

								</p> 
					</div>

			</div>
	</div>



  <!-- stats.js lib -->
  
  <script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
 function opendv() {
  document.getElementById("about").style.display = "block";
  document.getElementById("mySidenav").style.width = "0";
}
  function closedv() {
  document.getElementById("about").style.display = "none";
}
function openPage(pageName,elmnt,color) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].style.backgroundColor = "";
  }
  document.getElementById(pageName).style.display = "block";
  elmnt.style.backgroundColor = color;

}


// Get the element with id="defaultOpen" and click on it

  function opendiv(a,b) {
  document.getElementById(a).style.display = "block";
document.getElementById("mySidenav").style.width = "0"; 
 document.getElementById(b).click();
  
}
  function closediv(a) {
  document.getElementById(a).style.display = "none";
}
</script>
<script src="js/particle.min.js"></script>
   <script  src="js/index.js"></script>
</body>
<div class='overlay animated slideInDown' id="reg" >

		<a href="javascript:void(0)" class="closediv" onclick="closediv('reg')">&times;</a>
		<?php include("register.php"); ?>
	</div>
</html>
