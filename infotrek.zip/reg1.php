<?php
	session_start();
	include('connection.php');
$psw=$_POST["psw"];
$psw=sha1($psw);	
    $sql="SELECT id FROM sign1 WHERE rno='".$_POST["rno"]."' AND psw='".$psw."'";
	$res=mysqli_query($conn,$sql);
	$count=mysqli_num_rows($res);
	
	if($count==1)

	{   $_SESSION['username']=$_POST["rno"];
		$_SESSION["log"]="Login Successfully.";
		header("location:index.php");
	}
	else
	{
		$_SESSION["msg5"]="Invalid Username or Password. " .mysqli_error();
	header("location:index.php");

     }
?>