<!DOCTYPE html>
<html lang="en" >

<head>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-134427101-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-134427101-1');
</script>
  <title>INFOTREK'19</title>
 <link rel="icon" href="img/acm.png" type="image/gif" sizes="16x16">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/nevi.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
	 <link rel="stylesheet" href="css/event1.css">
  <link rel="stylesheet" href="css/animate.min.css">
  <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Iceland" />
  <style>
.grid-container {
  display: grid;
  grid-template-columns: 200px 200px 200px 200px;
  grid-template-rows: 200px 200px;
  grid-gap: 60px;
  background: none;
  padding: 10px;
}
  .border{
	  text-shadow: 1px 1px 2px black, 0 0 25px blue, 0 0 5px darkblue;
	    font-weight: 900;
		font-family:iceland;
}
  .cc{
   position:absolute;top:162px;left:440px;
  }
.grid-container > div {
  background-color: #fff;
  text-align: center;
  padding: 20px 0;
  font-size: 30px;
}
@media only screen and (max-width:500px) {
  /* For tablets: */
  .grid-container {
    width: 100%;
    padding: 0;
  }

 
}
</style>
<style>
.mydiv {
 border-radius: 50%;
  animation: myanimation 10s infinite;
}
.sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #fff;
  display: block;
  transition: 0.3s;

}

.sidenav a:hover {
  color: white;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

.zoom:hover {
  transform:scale(1.4);
}
</style>

</head>

<body id="acm">

    <div class="main">
	    <br><br>&nbsp;&nbsp;&nbsp;&nbsp;
<span style="font-size:40px;color:white;cursor:pointer;position:fixed;" onclick="openNav()">&#9776; </span>

	
	
	<img src="img/team1.png" class="team"><br><br><br><br><br>
	<div style="left:25%;position:absolute;top:110%;z-index:2;" class="animated zoomIn"><br>
		

		<div class="row" style="background-color:none;text-align:center; ">
	<div class=" col-sm-12" style="" >
	<img src="img/u1.jpg" class="zoom" style="height:180px;width:180px;border-radius:50%;">
	<br> <h3 style="color:white;text-align:center;font-family:Iceland;">Faculty Advisor<br>Dr. U Srinivasulu Reddy
	</h3>
		 </div></div>
	<div class="row" style="background-color:none; text-align:center;">
	<div class=" col-sm-4" style="margin-top:10px;" >
	<img src="img/ravina.jpeg" class="zoom" style="height:150px;width:150px;border-radius:50%;">
	<br> <h3 style="color:white;text-align:center;font-family:Iceland;">Ravina 
	</h3>
		 </div>
		
		  <div class=" col-sm-4" style="margin-top:10px;">
		  	<img src="img/nikki.jpeg" class="zoom" style="height:150px;width:150px;border-radius:50%;">
	<br> <h3 style="color:white;text-align:center;font-family:Iceland;">Nikki</h3>
		 </div> 
		  <div class=" col-sm-4" style="margin-top:10px;">
		  	<img src="img/preeti.jpg" class="zoom" style="height:150px;width:150px;border-radius:50%;">
	<br> <h3 style="color:white;text-align:center;font-family:Iceland;">preeti</h3>
		 </div>
		
		 </div>
		 
	
		 
		 
			<div class="row" style="background-color:none;border-radius: 25px; padding: 0px;text-align:center;padding-bottom:10px; ">
	<div class=" col-sm-3" style="margin-top:10px;" >
	<img src="img/amit.jpeg" class="zoom" style="height:150px;width:150px;border-radius:50%;">
	<br> <h3  style="color:white;text-align:center;font-family:Iceland;">Amit 
	</h3>
		 </div>
		
		  <div class=" col-sm-3" style="margin-top:10px;">
		  	<img class="zoom" src="img/RajRishi.jpeg" style="height:150px;width:150px;border-radius:50%;">
	<br> <h3 style="color:white;text-align:center;font-family:Iceland;">Raj Rishi</h3>
		 </div> 
		  <div class=" col-sm-3" style="margin-top:10px;">
		  	<img class="zoom" src="img/yash.jpeg" style="height:150px;width:150px;border-radius:50%;">
	<br> <h3 style="color:white;text-align:center;font-family:Iceland;">Yash</h3>
		 </div>
		  <div class=" col-sm-3" style="margin-top:10px;">
		  	<img class="zoom" src="img/yugansh.jpeg" style="height:150px;width:150px;border-radius:50%;">
		  
	<br> <h3 style="color:white;text-align:center;font-family:Iceland;">Yugansh</h3>
		 </div>
		 </div>
		 
		 </div>
		<br><br>

	     
  
		
	
	</div>
    		<div id="mySidenav" class="sidenav" style="position:fixed;z-index:3;">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
   <img src="img/logo.png" style="height:79px;width:261px;" align="right">
   <a href="index.php" class="border">HOME</a>
  <a href="javascript:void(0)" onclick="opendv()" class="border">ABOUT</a>
   <a href="event.php" class="border">EVENTS</a>
  <a href="glimpse.php" class="border">GLIMPSE</a>
  <a href="" class="border">TEAM</a>
  <a href="contact.php" class="border">CONTACT</a>
  <a href="javascript:void(0)" onclick="opendiv('reg')" class="border">REGISTER</a>
</div>

	


<script src="js/particle.min.js"></script>
  <!-- stats.js lib -->
  
  <script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
 function opendv() {
  document.getElementById("about").style.display = "block";
  document.getElementById("mySidenav").style.width = "0";
}
  function closedv() {
  document.getElementById("about").style.display = "none";
}
  function opendiv(a) {
  document.getElementById(a).style.display = "block";
  document.getElementById("mySidenav").style.width = "0";
}
  function closediv(a) {
  document.getElementById(a).style.display = "none";
}
</script>
 <div class='overlay animated slideInDown' id="about" >
   <a href="javascript:void(0)" class="closediv" onclick="closedv()">&times;</a>
  <P class="blocktext">
 
    <h1 style="font-family:Iceland;text-align:center;">ABOUT</h1><hr>
   Infotrek is an Inter-Department technical meet that is conducted every year. The festival includes Seminars and Guest Lectures by the software professionals from various organizations who have gained expertise in their field.The Department of Computer Applications has the unique distinction of being the pioneer in establishing India's first ACM Student's Chapter . ACM's headquarter is located in New York. It is dedicated to spreading computer awareness among students.This chapter regularly conducts seminars, lecture series and quiz contests apart from conducting annual meets like ACUMEN and INFOTREK. This chapter also releases a monthly online news magazine called the "ACM Newsletter" which keeps us abreast of the latest developments in the IT industry. ACM sponsors candidates for various MCA meets where our students participate and emerge in flying colours. Infotrek 2019 will be held from 23th February - 24th February 2019.
		</p>
 
  </div>
    <script  src="js/index.js"></script>
</body>
<div class='overlay animated slideInDown' id="reg" >

		<a href="javascript:void(0)" class="closediv" onclick="closediv('reg')">&times;</a>
		<?php include("register.php"); ?>
	</div>
</html>
