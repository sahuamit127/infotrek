<!DOCTYPE html>
<html lang="en" >

<head>
    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-134427101-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-134427101-1');
</script>
  <meta charset="UTF-8">
    <title>INFOTREK'19</title>
 <link rel="icon" href="img/acm.png" type="image/gif" sizes="16x16">
       
<meta http-equiv="X-UA-Compatible" content="IE=edge">
	  
	  <link rel="stylesheet" href="css/gallery.css">
	  <link rel="stylesheet" href="css/nevi.css">
   
	<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Iceland" />
    
    <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Droid+Sans:400,700" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
    <link rel="stylesheet" href="https://rawgit.com/LeshikJanz/libraries/master/Bootstrap/baguetteBox.min.css">

</head>
 <style>

.mydiv {
 border-radius: 50%;
  animation: myanimation 10s infinite;
}
.sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 5;
  top: 0;
  left: 0;
  background-color:#111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #fff;
  display: block;
  transition: 0.3s;

}
.border{
	  text-shadow: 1px 1px 2px black, 0 0 25px blue, 0 0 5px darkblue;
	    font-weight: 950;
		font-family:iceland;
}
 .cc{
   position:absolute;top:300%;left:29%;
  }
.sidenav a:hover {
  color: white;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
  </style>

<body style="background-color:#212529;">
 <br><br>&nbsp;&nbsp;&nbsp;&nbsp;
	<span style="font-size:40px;color:white;cursor:pointer;position:fixed;" onclick="openNav()">&#9776; </span>
	   		<div id="mySidenav" class="sidenav" style="position:absolute;z-index:3;">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
   <img src="img/logo.png" style="height:79px;width:261px;" align="right">
   <a href="index.php" class="border">HOME</a>
  <a href="javascript:void(0)" onclick="opendv()" class="border">ABOUT</a>
   <a href="event.php" class="border">EVENTS</a>
  <a href="#" class="border">GLIMPSE</a>
  <a href="team.php" class="border">TEAM</a>
  <a href="contact.php" class="border">CONTACT</a>
  <a href="javascript:void(0)" onclick="opendiv('reg')" class="border">REGISTER</a>
</div>
<div class="container gallery-container">

    <p style="text-align:center;color:#fff;font-size:48px;font-weight:bold;font-family:iceland;">Glimpse</p>

   
    
    <div class="tz-gallery">

        <div class="row">

            <div class="col-sm-12 col-md-4">
                <a class="lightbox" href="gallery/a.jpg">
                    <img src="gallery/a.jpg" alt="Bridge">
                </a>
            </div>
            <div class="col-sm-6 col-md-4">
                 <a class="lightbox" href="gallery/b.jpg">
                    <img src="gallery/b.jpg" alt="Bridge">
				</a>
            </div>
            <div class="col-sm-6 col-md-4">
                  <a class="lightbox" href="gallery/c.jpg">
                    <img src="gallery/c.jpg" alt="Bridge">              
			   </a>
            </div>
            <div class="col-sm-12 col-md-4">
                <a class="lightbox" href="gallery/d.jpg">
                    <img src="gallery/d.jpg" alt="Bridge">
                </a>
            </div>
            <div class="col-sm-6 col-md-4">
                 <a class="lightbox" href="gallery/e.jpg">
                    <img src="gallery/e.jpg" alt="Bridge">
				</a>
            </div>
            <div class="col-sm-6 col-md-4">
                  <a class="lightbox" href="gallery/f.jpg">
                    <img src="gallery/f.jpg" alt="Bridge">              
			   </a>
            </div>
			<div class="col-sm-12 col-md-4">
                <a class="lightbox" href="gallery/g.jpg">
                    <img src="gallery/g.jpg" alt="Bridge">
                </a>
            </div>
            <div class="col-sm-6 col-md-4">
                 <a class="lightbox" href="gallery/h.jpg">
                    <img src="gallery/h.jpg" alt="Bridge">
				</a>
            </div>
            <div class="col-sm-6 col-md-4">
                  <a class="lightbox" href="gallery/i.jpg">
                    <img src="gallery/i.jpg" alt="Bridge">              
			   </a>
            </div>

        </div>

    </div>

</div>
  <script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
 function opendv() {
  document.getElementById("about").style.display = "block";
  document.getElementById("mySidenav").style.width = "0";
}
  function closedv() {
  document.getElementById("about").style.display = "none";
}
  function opendiv(a) {
  document.getElementById(a).style.display = "block";
  document.getElementById("mySidenav").style.width = "0";
}
  function closediv(a) {
  document.getElementById(a).style.display = "none";
}

  </script>
<?php include("footer.php"); ?>


<script src="js/gallery.js"></script>
<script>
    baguetteBox.run('.tz-gallery');
</script>
<div class='overlay animated slideInDown' id="about" >
   <a href="javascript:void(0)" class="closediv" onclick="closedv()">&times;</a>
  <P class="blocktext">
<h1 style="font-family:Iceland;text-align:center;">ABOUT</h1><hr>
  Infotrek is an Inter-Department technical meet that is conducted every year. The festival includes Seminars and Guest Lectures by the software professionals from various organizations who have gained expertise in their field.The Department of Computer Applications has the unique distinction of being the pioneer in establishing India's first ACM Student's Chapter . ACM's headquarter is located in New York. It is dedicated to spreading computer awareness among students.This chapter regularly conducts seminars, lecture series and quiz contests apart from conducting annual meets like ACUMEN and INFOTREK. This chapter also releases a monthly online news magazine called the "ACM Newsletter" which keeps us abreast of the latest developments in the IT industry. ACM sponsors candidates for various MCA meets where our students participate and emerge in flying colours. Infotrek 2019 will be held from 23th February - 24th February 2019.
		</p>
 
  </div>
</body>
<div class='overlay animated slideInDown' id="reg" >

		<a href="javascript:void(0)" class="closediv" onclick="closediv('reg')">&times;</a>
		<?php include("register.php"); ?>
	</div>
</html>
  
  


