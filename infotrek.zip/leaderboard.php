<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/font.css">

<link rel="stylesheet" type="text/css" href="css/animate.css">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<title>The Hobbit Leaderboard</title>
<style>
body
{
background-color:#ffffff;
}

h1,h2{
	text-align:center;
 color:white;
}
table,td,tr,th
{
	color: white;
	border:3px solid #007acc;
}
</style>
</head>
<body class="myfont" style="overflow-x:hidden; background-color: #001524;">

<h1><b>The Hobbit</b></h1>
<h2><b>LEADERBOARD</b></h2>
<div style="margin-left:20px">
<table class="table table-bordered animated fadeInDownBig"   style="  width:40% ; margin-left: auto; margin-right: auto; text-align: center; font-weight: 500;" >
<thead style="border:3px solid #007acc;">
<tr>
<th style="text-align: center;">NAME</th>
<th style="text-align: center;">SCORE</th>
</tr>
</thead> 
<?php 
	$con=mysqli_connect("localhost","root","ada_venture@18","infotrek");
	$sql = "SELECT * FROM `user_score` where user_name!=205116035 and user_name!=205116067 ORDER BY `score` DESC LIMIT 15 ";
	$result = mysqli_query($con, $sql);
	while($row = mysqli_fetch_array($result)){
		echo '<tr>
			<td>'.$row["name"].'</td> 
			<td>'.$row["score"].'</td>
			</tr>';
      }
?>
</table>
  <a href="events.php"  style="text-decoration: none;" ><h2 id="a2" style="background-color:brown; color: #fff; margin-left: auto; margin-right: auto; border: 2px solid #fff; padding: 10px; width: 150px; font-family: iceland; text-decoration: none;  align="middle" class="animated fadeInDownBig">Back</h2></a>
      
</tr>

<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>

</body>
</html>