<?php
?>
<!doctype html>
<html><head>
<meta charset="utf-8">
<title>ACM Student Chapter</title>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/main.css">
   <!-- Style -->
    
    

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<link href='https://fonts.googleapis.com/css?family=Orbitron:900,700' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Audiowide' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

    
<!-- Latest compiled JavaScript -->
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/sweetalert2/4.0.6/sweetalert2.min.css">
<script  src="https://cdn.jsdelivr.net/sweetalert2/4.0.6/sweetalert2.min.js"></script>

<link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso.css" /> 
<!-- Inline CSS based on choices in "Settings" tab -->
<style>.bootstrap-iso .form-group button, .bootstrap-iso form input.form-control, .bootstrap-iso form textarea.form-control, .bootstrap-iso form select.form-control{-webkit-border-radius: 0 !important;-moz-border-radius: 0; border-radius: 0;}.bootstrap-iso .formden_header h2, .bootstrap-iso .formden_header p, .bootstrap-iso form{font-family: Arial, Helvetica, sans-serif; color: black}.bootstrap-iso form button, .bootstrap-iso form button:hover{color: white !important;} .bootstrap-iso .btn-custom{background: #00a3bb} .bootstrap-iso .btn-custom:hover{background: #008fa7;} .asteriskField{color: red;}.bootstrap-iso form .input-group-addon {color:#555555; background-color: #eeeeee; border-radius: 0px; padding-left:12px}</style>

<style>
header {
 
 height:150px;background-color: #005ca3;
background-image: url("https://www.transparenttextures.com/patterns/carbon-fibre.png");
/* This is mostly intended for prototyping; please download the pattern and re-host for production environments. Thank you! */
-webkit-box-shadow: 0px 3px 5px 0px rgba(31,166,123,1);
-moz-box-shadow: 0px 3px 5px 0px rgba(31,166,123,1);
box-shadow: 0px 3px 5px 0px rgba(31,166,123,1);
}

/*
Fade content bs-carousel with hero headers
Code snippet by maridlcrmn (Follow me on Twitter @maridlcrmn) for Bootsnipp.com
Image credits: unsplash.com
*/

/********************************/
/*       Fade Bs-carousel       */
/********************************/
.fade-carousel {
    position: relative;
    height: 450px;
}
.fade-carousel .carousel-inner .item {
    height: 450px;
}
.fade-carousel .carousel-indicators > li {
    margin: 0 2px;
    background-color: #f39c12;
    border-color: #f39c12;
    opacity: .7;
}
.fade-carousel .carousel-indicators > li.active {
  width: 10px;
  height: 10px;
  opacity: 1;
}

/********************************/
/*          Hero Headers        */
/********************************/
.hero {
    position: absolute;
    top: 50%;
    left: 50%;
    z-index: 3;
    color: #fff;
    text-align: center;
    text-transform: uppercase;
    text-shadow: 1px 1px 0 rgba(0,0,0,.75);
      -webkit-transform: translate3d(-50%,-50%,0);
         -moz-transform: translate3d(-50%,-50%,0);
          -ms-transform: translate3d(-50%,-50%,0);
           -o-transform: translate3d(-50%,-50%,0);
              transform: translate3d(-50%,-50%,0);
}
.hero h1 {
    font-size: 6em;    
    font-weight: bold;
    margin: 0;
    padding: 0;
}

.fade-carousel .carousel-inner .item .hero {
    opacity: 0;
    -webkit-transition: 2s all ease-in-out .1s;
       -moz-transition: 2s all ease-in-out .1s; 
        -ms-transition: 2s all ease-in-out .1s; 
         -o-transition: 2s all ease-in-out .1s; 
            transition: 2s all ease-in-out .1s; 
}
.fade-carousel .carousel-inner .item.active .hero {
    opacity: 1;
    -webkit-transition: 2s all ease-in-out .1s;
       -moz-transition: 2s all ease-in-out .1s; 
        -ms-transition: 2s all ease-in-out .1s; 
         -o-transition: 2s all ease-in-out .1s; 
            transition: 2s all ease-in-out .1s;    
}

/********************************/
/*            Overlay           */
/********************************/
.overlay {
    position: absolute;
    width: 100%;
    height: 100%;
    z-index: 2;
    background-color: #080d15;
    opacity: .7;
}

/********************************/
/*          Custom Buttons      */
/********************************/
.btn.btn-lg {padding: 10px 40px;}
.btn.btn-hero,
.btn.btn-hero:hover,
.btn.btn-hero:focus {
    color: #f5f5f5;
    background-color: #1abc9c;
    border-color: #1abc9c;
    outline: none;
    margin: 20px auto;
}

/********************************/
/*       Slides backgrounds     */
/********************************/
.fade-carousel .slides .slide-1, 
.fade-carousel .slides .slide-2,
.fade-carousel .slides .slide-3 {
  height: 100vh;
  background-size: cover;
  background-position: center center;
  background-repeat: no-repeat;
}
.fade-carousel .slides .slide-1 {
  background-image: url(https://ununsplash.imgix.net/photo-1416339134316-0e91dc9ded92?q=75&fm=jpg&s=883a422e10fc4149893984019f63c818); 
}
.fade-carousel .slides .slide-2 {
  background-image: url(https://ununsplash.imgix.net/photo-1416339684178-3a239570f315?q=75&fm=jpg&s=c39d9a3bf66d6566b9608a9f1f3765af);
}
.fade-carousel .slides .slide-3 {
  background-image: url(https://ununsplash.imgix.net/photo-1416339276121-ba1dfa199912?q=75&fm=jpg&s=9bf9f2ef5be5cb5eee5255e7765cb327);
}

/********************************/
/*          Media Queries       */
/********************************/
@media screen and (min-width: 980px){
    .hero { width: 980px; }    
}
@media screen and (max-width: 640px){
    .hero h1 { font-size: 4em; }    
}
/*
img {
  height: 230px;

}*/


h4 {
  padding:10px;
  background: #000;
  color:#fff;
  font-family: 'Orbitron', serif;
  margin-top: -4px;
}
.editContent p {
  color:#00CC99;;
  font-family: 'Audiowide';
  margin-bottom: 20px;
  margin-top: -5px;
  text-transform: uppercase;
  font-size: 17px;
}
p
{


  
  color: white;
}
</style>
</head>

<body>
<div class="news_ticker"><?php include('includes/news.html');?></div>
<header>
<div class="container">
<div class=" col-md-2" >
<img class="img-responsive hide_mobile " style="margin-top:20px"  src="images/nitt.png" width="115">
</div>
<div class="  col-sm-8 " ><h2 class="hide_mobile" style="color:#fff;font-family: 'Orbitron', sans-serif;   text-align:center">National Institute of Technology, Tiruchirappalli</h2>
<h3 class="hide_desktop " style="color:#fff;font-family: 'Orbitron', sans-serif;   text-align:center">National Institute of Technology, Tiruchirappalli</h3>
<h2 class="hide_mobile" style="color:#fbc200; font-family: 'Audiowide', cursive;  text-align:center">ACM Student Chapter</h2>
<h4 class="hide_desktop "  style="color:#fbc200; font-family: 'Audiowide', cursive;  text-align:center">ACM Student Chapter</h4></div>
<div class="col-md-2" >
<img class="img-responsive hide_mobile " style="margin-top:20px" src="images/acm.png" width="115">
</div>
</div>
</header>


<!-- HTML Form (wrapped in a .bootstrap-iso div) -->
  <div class="">
  <nav class="navbar navbar-default navbar-inverse">
<div class="container-fluid">
<div class="navbar-header">
<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">NITT ACM</a>
          </div>
          <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
              <li ><a href="index.php"><i class="fa fa-home"></i> Home</a></li>
               <li><a href="about.php"><i class="fa fa-info-circle"></i> About</a></li>
             
              <li><a href="events.php"><i class="fa fa-trophy"></i> Events</a></li>
              <li><a href="team.php"><i class="fa fa-users"></i> Team</a></li>
              <li><a href="task.php"><i class="fa fa-cog fa-spin"></i> ACM Induction 2018</a></li>
            
          
             
            </ul>
            
            <ul class="nav navbar-nav navbar-right">
            
                      <form class="navbar-form navbar-right " role="search">
           
           
  <a href="register.php"><button type="button" class="btn btn-success" style="background:#007E58">Register</button></a>

 
              
             
             
             
  
  
</form>
 
            </ul>
          </div><!--/.nav-collapse -->
        </div><!--/.container-fluid -->
      </nav>
  
  
  
  
  </div>
    <div id="page" class="page" style="background:#333333;margin-top:-20px; margin-bottom:-20px;">
        
          <div class="container">
        
          <div class="row margin-bottom-40">
          
            <div class="col-md-12">
            
              <h2 class="text-center" style="margin-top:90px; margin-bottom:300px;color:#7EC2EB;font-family: 'Orbitron', sans-serif;">
               Coming Soon
              </h2>
            
            </div><!-- /.col-md-12 -->
          
          </div><!-- /.row -->
                </div>
           <div class="container">
          
           </div>
             
      
  




      </div><!-- /#page -->




<footer class="col-md-12" style="background:#000;bottom:0"><p style="color:#FFF; text-align:center">Made with <span class="glyphicon glyphicon-heart" style="color:red"></span> by NITT ACM</p>
</footer>
<script src="js/ticker.js"></script>
</body>
</html>
