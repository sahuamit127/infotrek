<!DOCTYPE html>
<html lang="en" >

<head>


  <title>INFOTREK'19</title>
 <link rel="icon" href="img/acm.png" type="image/gif" sizes="16x16">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/nevi.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
  <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Iceland" />
	 <link rel="stylesheet" href="css/event1.css">
  <link rel="stylesheet" href="css/animate.min.css">
  <style>
.grid-container {
  display: grid;
  grid-template-columns: 200px 200px 200px 200px;
  grid-template-rows: 200px 200px;
  grid-gap: 60px;
  background: none;
  padding: 10px;
}
  .border{
	  text-shadow: 1px 1px 2px black, 0 0 25px blue, 0 0 5px darkblue;
	    font-weight: 900;
		font-family:iceland;
}
  .cc{
   position:absolute;top:162px;left:440px;
  }
.grid-container > div {
  background-color: #fff;
  text-align: center;
  padding: 20px 0;
  font-size: 30px;
}
@media only screen and (max-width:500px) {
  /* For tablets: */
  .grid-container {
    width: 100%;
    padding: 0;
  }

 
}
</style>
<style>
.mydiv {
 border-radius: 50%;
  animation: myanimation 10s infinite;
}
.sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #fff;
  display: block;
  transition: 0.3s;

}

.sidenav a:hover {
  color: white;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
@keyframes myanimation {
  0% {background-color: red;}
  25%{background-color:blue;}
  50%{background-color:green;}
  75%{background-color:brown;}
  100% {background-color: red;}
}
</style>
<style>

.inc{
  height: 150px;
  width: 150px;
 border-radius:50%;

  margin-left:10px;
  margin-right:10px;
   margin-top:10px;
}
.con_name{
color:white;
font-size: 25px;
    font-weight: 900;
	position:absolute;
}



.blur:hover {
  transform:scale(1.6);
}
</style>
</head>

<body id="acm">

    <div class="main">
	    <br><br>&nbsp;&nbsp;&nbsp;&nbsp;
<span style="font-size:40px;color:white;cursor:pointer" onclick="openNav()">&#9776; </span>

	
	
	<img src="img/CONTACT1.png" class="event_name">
	<div style="left:18%;position:absolute;top:110%;z-index:3;">
	
	<div class="row animated zoomIn" style="background-color:none;border-radius: 25px; padding: 100px;text-align:center; ">
	<div class=" col-sm-3" style="margin-top:10px;" >
	<img src="img/yash.jpeg" class="blur"  style="height:150px;width:150px;border-radius:50%;">
	<br> <h3 style="color:white;text-align:center;font-family:Iceland;">Yash
	<br>+918077843470</h3>
		 </div>
		
		  <div class=" col-sm-3" style="margin-top:10px;">
		  	<img src="img/amit.jpeg" class="blur" style="height:150px;width:150px;border-radius:50%;">
	<br> <h3 style="color:white;text-align:center;font-family:Iceland;">Amit
	<br>+918602117954</h3>
		 </div> 
		  <div class=" col-sm-3" style="margin-top:10px;">
		  	<img src="img/yugansh.jpeg" class="blur"  style="height:150px;width:150px;border-radius:50%;">
	<br> <h3 style="color:white;text-align:center;font-family:Iceland;">Yugansh
	<br>+919993562253</h3>
		 </div>
		  <div class=" col-sm-3" style="margin-top:10px;">
		  	<img src="img/RajRishi.jpeg" class="blur"  style="height:150px;width:150px;border-radius:50%;">
	<br> <h3 style="color:white;text-align:center;font-family:Iceland;">Raj Rishi
	<br>+917903889336</h3>
		 </div>
		 </div>
		
		 
		 </div>
		<br><br>

	     
  
		
	
	</div>
    		<div id="mySidenav" class="sidenav" style="position:absolute;z-index:3;">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
   <img src="img/logo.png" style="height:79px;width:261px;" align="right">
   <a href="index.php" class="border">HOME</a>
  <a href="javascript:void(0)" onclick="opendiv('about')" class="border">ABOUT</a>
   <a href="event.php" class="border">EVENTS</a>
  <a href="glimpse.php" class="border">GLIMPSE</a>
  <a href="team.php" class="border">TEAM</a>
  <a href="" class="border">CONTACT</a>
  <a href="javascript:void(0)" onclick="opendiv('reg')" class="border">REGISTER</a>
</div>

<?php include("footer.php"); ?>

</div>

 <script src="js/particle.min.js"></script>
<script  src="js/index.js"></script>
  <!-- stats.js lib -->
  
  <script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
  function opendiv(a) {
  document.getElementById(a).style.display = "block";
  document.getElementById("mySidenav").style.width = "0";
}
  function closediv(a) {
  document.getElementById(a).style.display = "none";
}
</script>
 <div class='overlay animated slideInDown' id="about" >
   <a href="javascript:void(0)" class="closediv" onclick="closediv('about')">&times;</a>
  <P class="blocktext">
  <h1 style="font-family:Iceland;text-align:center;">ABOUT</h1><hr>
  Infotrek is an Inter-Department technical meet that is conducted every year. The festival includes Seminars and Guest Lectures by the software professionals from various organizations who have gained expertise in their field.The Department of Computer Applications has the unique distinction of being the pioneer in establishing India's first ACM Student's Chapter . ACM's headquarter is located in New York. It is dedicated to spreading computer awareness among students.This chapter regularly conducts seminars, lecture series and quiz contests apart from conducting annual meets like ACUMEN and INFOTREK. This chapter also releases a monthly online news magazine called the "ACM Newsletter" which keeps us abreast of the latest developments in the IT industry. ACM sponsors candidates for various MCA meets where our students participate and emerge in flying colours. Infotrek 2018 will be held from 23th February - 24th February 2019.
		</p>
 
  </div>
   
</body>
<div class='overlay animated slideInDown' id="reg" >

		<a href="javascript:void(0)" class="closediv" onclick="closediv('reg')">&times;</a>
		<?php include("register.php"); ?>
	</div>
</html>
