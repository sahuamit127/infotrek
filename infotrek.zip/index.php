<!DOCTYPE html>
<html lang="en" >

<head>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-134427101-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-134427101-1');
</script>
<script>
function blinker() {
	$('#foo').fadeOut(500);
	$('#foo').fadeIn(500);
}
setInterval(blinker, 1000);
</script>
 <style>

.mydiv {
 border-radius: 50%;
  animation: myanimation 10s infinite;
}
.sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 5;
  top: 0;
  left: 0;
  background-color:#111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #fff;
  display: block;
  transition: 0.3s;

}
.border{
	  text-shadow: 1px 1px 2px black, 0 0 25px blue, 0 0 5px darkblue;
	    font-weight: 950;
		font-family:iceland;
}
 .cc{
   position:absolute;top:300%;left:29%;
  }
.sidenav a:hover {
  color: white;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
  </style>

<style>
.middle {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  text-align: center;
  z-index:1;
  color:white;
  font-weight:900;
  font-size:30px;
}
.blinking{
	animation:blinkingText 2s infinite;
	position:absolute;
	top:75%;
	left:42%;
	font-family:iceland;
	text-shadow: 2px 2px 5px #136afb;
}
@keyframes blinkingText{
	0%{		color: #fff;
transform:scale(1.5);	}
	24%{	color: transparent;	}
	25%{	color: #fff;
         transform:scale(1.8);	}
	50%{	color: transparent;	}
	75%{	color: #fff;
         transform:scale(2.2);	}
	99%{	color:transparent;	}
	100%{	color: #fff;
         transform:scale(2.5);	}
}
.live
{
	position:absolute;top:34%;left:11%;
}
@media only screen and (max-width:500px) {
	
	
	
	.blinking{
	
	
	left:30%;
	
	font-size:18px;
	text-shadow: 2px 2px 5px #136afb;
}
.live
{
	position:absolute;top:32%;left:11%;
	height:100px;
	width:100px;
}
}

</style>
  <title>INFOTREK'19</title>
 <link rel="icon" href="img/acm.png" type="image/gif" sizes="16x16">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

  <link href="./css/icon_style.css" rel="stylesheet">
  <link rel="stylesheet" href="css/animate.min.css">
      <link rel="stylesheet" href="css/style.css">
	    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
	<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Iceland" />
 <link rel="stylesheet" href="css/nevi.css">
 <link rel="stylesheet" href="css/center_animation.css">
</head>

<body id="acm">

<div class="main">
      <br><br>&nbsp;&nbsp;&nbsp;&nbsp;
	<span style="font-size:40px;color:white;cursor:pointer" onclick="openNav()">&#9776; </span>
	
	
	
	<br><br>
<img src="img/logo.png" class="ims animated rubberBand ilogo" align="right" >
	
	
	
	</div>
	   		<div id="mySidenav" class="sidenav" style="position:absolute;z-index:3;">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
   <img src="img/logo.png" style="height:79px;width:261px;" align="right">
   <a href="#" class="border">HOME</a>
  <a href="javascript:void(0)" onclick="opendv()" class="border">ABOUT</a>
   <a href="event.php" class="border">EVENTS</a>
  <a href="glimpse.php" class="border">GLIMPSE</a>
  <a href="team.php" class="border">TEAM</a>
  <a href="contact.php" class="border">CONTACT</a>
  <a href="javascript:void(0)" onclick="opendiv('reg')" class="border">REGISTER</a>
</div>

 <div id="content" style="transform: translateY(-100px) scaleX(0.7) scaleY(0.7) scaleZ(0.7);">
   
    <div id="layers" class="core-layer" style="text-align: center;">
      <div class="layer" id="layer1">
        <img src="./img/layer1s.png">
      </div>
      <div class="layer" id="layer2">
        <img src="./img/layer2s.png">
      </div>
      <div class="layer" id="layer3">
       <img src="./img/layer3s.png">
      </div>
      <div class="layer" id="layer4">
        <img src="./img/layer4s.png">
		
      </div>
	  
    </div>

  </div>
   
      <div class="loader">
            <div class="element-animation">
            <img src="img/aaaa.png" width="480" height="100";>
            </div>
     </div>
    <h1 class="blinking" >23-24th february</h1>
 
 
 <div class="live">
	<a href="hunt1/login.php" style="text-decoration:none;"> <img src="sad.png">
	 <h3 style="font-family: iceland; color: rgb(255, 255, 255); opacity: 0.933535;" id="foo">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Live</h3> </a>
	 </div>
<?php include("footer.php"); ?>

  <div class='overlay animated slideInDown' id="about" >
   <a href="javascript:void(0)" class="closediv" onclick="closedv()">&times;</a>
  <P class="blocktext">
  <h1 style="font-family:Iceland;text-align:center;">ABOUT</h1><hr>
   Infotrek is an Inter-Department technical meet that is conducted every year. The festival includes Seminars and Guest Lectures by the software professionals from various organizations who have gained expertise in their field.The Department of Computer Applications has the unique distinction of being the pioneer in establishing India's first ACM Student's Chapter . ACM's headquarter is located in New York. It is dedicated to spreading computer awareness among students.This chapter regularly conducts seminars, lecture series and quiz contests apart from conducting annual meets like ACUMEN and INFOTREK. This chapter also releases a monthly online news magazine called the "ACM Newsletter" which keeps us abreast of the latest developments in the IT industry. ACM sponsors candidates for various MCA meets where our students participate and emerge in flying colours. Infotrek 2019 will be held from 23th February - 24th February 2019.
		</p>
 
  </div>
  <!-- stats.js lib -->
  
  <script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
 function opendv() {
  document.getElementById("about").style.display = "block";
  document.getElementById("mySidenav").style.width = "0";
}
  function closedv() {
  document.getElementById("about").style.display = "none";
}
  function opendiv(a) {
  document.getElementById(a).style.display = "block";
  document.getElementById("mySidenav").style.width = "0";
}
  function closediv(a) {
  document.getElementById(a).style.display = "none";
}

  </script>

	
  
  
    <script src="js/particle.min.js"></script>
    <script  src="js/index.js"></script>
 

<div class='overlay animated slideInDown' id="reg" >

		<a href="javascript:void(0)" class="closediv" onclick="closediv('reg')">&times;</a>
		<?php include("register.php"); ?>
	</div>
<!-- end document-->
 
</body>

</html>
