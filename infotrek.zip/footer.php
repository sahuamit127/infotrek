<style>
.nitlogo{
float:left;height:76px;width:400px;
}
.acmlogo{
float:right;width:400px;height:76px;
}
.social{
position:absolute;left:43%;
z-index:5;
text-align:center;

}
@media only screen and (max-width:500px) {
  /* For tablets: */
  .nitlogo,.acmlogo{
  display:none;
  
  }
  .social{
	  position:absolute;left:17%;
	 
	  z-index:5;
	  text-align:center;
  }
  
}
@media only screen and (max-width:800px) {
  /* For tablets: */
  .nitlogo,.acmlogo{
  display:none;
  
  }
  .social{
	  position:absolute;left:20%;
	  margin-bottom:1800px;
	  z-index:5;
	  
  }
  
}
.zoom:hover {
  -ms-transform: scale(1.3); /* IE 9 */
  -webkit-transform: scale(1.3); /* Safari 3-8 */
  transform: scale(1.3); 
}



</style>
<div class="footer">
&nbsp;	<img src="img/nittnew.png" class="animated zoomIn nitlogo">

             
			  <div class="social">
			  
          <a href="https://plus.google.com/u/0/109507741940334100025"> <img src="img/email.png"  style="height:40px;width:40px;" class="zoom"></a>&nbsp;&nbsp;&nbsp;
			 <a href="https://www.facebook.com/ACM.NITT/"><img src="img/fb.png" style="height:40px;width:40px;" class="zoom"></a>&nbsp;&nbsp;&nbsp;
			<a href="https://twitter.com/acm_nitt"><img src="img/tw.png" style="height:40px;width:40px;" class="zoom"></a>&nbsp;&nbsp;&nbsp;
			<br><h4 style="font-family:iceland;">Made With ❤️ by ACM NITT</h4>
			
    </div>

	<img src="img/acmnew.png"  class="animated zoomIn acmlogo" >
</div>