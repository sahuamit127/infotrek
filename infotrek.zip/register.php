
    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">
     
    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
	 <link rel="stylesheet" href="css/animate.min.css">
	 <link rel="stylesheet" href="css/sweet-alert.css">
 
	
    <div class="page-wrapper bg-gra-01 p-t-180 p-b-100 font-poppins">
        <div class="wrapper wrapper--w780">
            <div class="card card-3">
               
                <div class="card-body">
                    <h1 class="title"></h1>
                    <form method="POST" action="register1.php">
                        <div class="input-group">
                            <input class="input--style-3" type="text" placeholder="First Name" name="fname" required>
                        </div>
                      <div class="input-group">
                            <input class="input--style-3" type="text" placeholder="Last Name" name="lname" required>
                        </div>
                       
                        <div class="input-group">
                            <input class="input--style-3" type="email" placeholder="Email" name="email" required>
                        </div>
                        <div class="input-group">
                            <input class="input--style-3" type="number" placeholder="Phone" name="cno" required>
                        </div>
						<div class="input-group">
                            <input class="input--style-3" type="number" placeholder="Roll No." name="rno" required>
                        </div>
						<div class="input-group">
                            <input class="input--style-3" type="text" placeholder="Department" name="department" required>
                        </div>
						<div class="input-group">
                            <input class="input--style-3" type="password" placeholder="password" name="psw" required>
                        </div>
						<div class="input-group">
                            <input class="input--style-3" type="password" placeholder="confirm password" name="cpsw" required>
                        </div>
                        <div class="p-t-10">
                            <input class="btn btn--pill btn--green" type="submit" value="Register">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Jquery JS-->
	<script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/sweet-alert.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
 

    <!-- Main JS-->
    <script src="js/global.js"></script>
 
